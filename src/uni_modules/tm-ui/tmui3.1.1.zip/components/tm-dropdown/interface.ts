export interface itemList {
    text: string,
    iconColor?: string,
    icon?: string,
    [prop: string]: any
}