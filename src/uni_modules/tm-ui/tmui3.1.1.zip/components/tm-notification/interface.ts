export interface showOpts {
    label?: string,
    icon?: string,
    duration?: number,
    color?: string
}